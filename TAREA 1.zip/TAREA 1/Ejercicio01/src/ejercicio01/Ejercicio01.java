
package ejercicio01;


public class Ejercicio01 {


    public static void main(String[] args) {
       // variables enteras de "x" e "y"
        int x = 144;
       int y = 999;
       // Variables para las operaciones
       int suma, mult, resta;
       double div;
        System.out.println("El valor de x es: "+ x);
        System.out.println("El valor de y es: "+ y);
        // OPERACIONES:
        suma = x + y;
        resta = x - y;
        mult = x*y;
        div = x/y;
        System.out.println("La suma es: "+suma);
        System.out.println("La resta es: "+resta);
        System.out.println("La multiplicacion es: "+mult);
        System.out.println("La division es: "+div);
        
    }
    
}
