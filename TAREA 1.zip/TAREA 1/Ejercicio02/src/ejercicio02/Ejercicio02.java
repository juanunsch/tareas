
package ejercicio02;

import java.util.Scanner;


public class Ejercicio02 {

   
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        // la valor del dolar en nuestro pais es de  3.36
        float tc = 3.36f;
        float dolar, soles, a, b;
        
        // operaciones de conversion de dolar a solos y viceversa
        System.out.print("ingrese el monto de dolar que desea convertir a soles: ");
        a = entrada.nextFloat();
        
        System.out.print("ingrese el monto de soles que desea convertir a dolar: ");
        b = entrada.nextFloat();
        
        dolar = b/tc;
        soles = a*tc;
        
        System.out.println("\n El monto q tiene en soles es de: "+" S/. "+soles);
        System.out.println("El monto que tiene en dolares es de: "+dolar+" dolares");
        
    }
    
}
