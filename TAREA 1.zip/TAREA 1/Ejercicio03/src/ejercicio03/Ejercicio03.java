
package ejercicio03;

import java.util.Scanner;

public class Ejercicio03 {

   public static void main(String[] args) {
        float precio1, precio2,precio3,total;
        Scanner entrada = new Scanner(System.in);
        //Prcios de las facturas ingresadas
        System.out.println("Ingrese el precio de la computadora por favor: ");
        precio1=entrada.nextInt();
        System.out.println("Ingrese el precio de la mause por favor: ");
        precio2=entrada.nextInt();
        System.out.println("Ingrese el precio del rauter por favor: ");
        precio3=entrada.nextInt();
        
        //Precio total acumulada en la factura sin igv
        total = precio1 + precio2 + precio3;
        System.out.println("\n---------------------------------------------------------");
        System.out.println("El precio total de la factura es el monto de: " + total);
    }
   
    
}
